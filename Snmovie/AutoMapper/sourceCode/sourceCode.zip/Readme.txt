The source code can be found at GitHub:

https://github.com/jbogard/AutoMapper