# Next major version
* Silverlight support
* Mono support
* CF support
* Composite mappings (mapping 2+ source types to 1 destination type)
* First-class reverse mapping support
* A StructureMap-like MappingRegistry configuration helper
* Supporting layer supertypes/interfaces (i.e., configuration for a layer supertype or interface gets applied to subtypes or implementors)
* Mapping to interfaces with read-only members
* Mapping to any IEnumerable with an Add method (to support any collection type)