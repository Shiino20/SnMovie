# ATTENTION

# AutoMapper has moved to GitHub

AutoMapper has completely moved to GitHub:

[https://github.com/AutoMapper/AutoMapper](https://github.com/AutoMapper/AutoMapper)

The site can be found at [http://automapper.org](http://automapper.org)

All issues should be reported on GitHub. No issues will be responded to on CodePlex.

I can't turn anything off on CodePlex without deleting the whole site, which would be very confusing.

The latest downloads can be found at NuGet or at GitHub.